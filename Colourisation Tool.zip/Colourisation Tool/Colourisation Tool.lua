local InCol = Color{r = "128", g = "128", b = "128", a = "255"};
local OutCol = Color{r = "255", g = "255", b = "255", a = "255"};
local Hue = 180;
local Sat = 50;
local SatMax = 100;

function rgb2v(r,g,b)
  return (0.21*r + 0.71*g + 0.07*b)
end

function hsv2rgb(h, s, v)
  -- Credit to David Hoerl for the basis of this function
  -- https://stackoverflow.com/questions/3018313/algorithm-to-convert-rgb-to-hsv-and-hsv-to-rgb-in-range-0-255-for-both

  local hh, p, q, t, ff, i

  hh = h
  if(hh >= 360.0) then hh = 0.0 end
  hh = hh / 60.0
  i = math.floor(hh)
  ff = hh - i
  p = v * (1.0 - s)
  q = v * (1.0 - (s * ff))
  t = v * (1.0 - (s * (1.0 - ff)))

  local case =
  {
    [0] = Color{r = 255*v, g = 255*t, b = 255*p, a = 255},
    [1] = Color{r = 255*q, g = 255*v, b = 255*p, a = 255},
    [2] = Color{r = 255*p, g = 255*v, b = 255*t, a = 255},
    [3] = Color{r = 255*p, g = 255*q, b = 255*v, a = 255},
    [4] = Color{r = 255*t, g = 255*p, b = 255*v, a = 255},
    [5] = Color{r = 255*v, g = 255*p, b = 255*q, a = 255}
  }

  return case[i]
end

function calculateCol()
  local inv255 = 0.00392156862745   -- 1 / 255

  -- Calculating and setting the maximum valid saturation value
  local tempCol = hsv2rgb(Hue, 1.0, 1.0)
  local valueHue = rgb2v(tempCol.red, tempCol.green, tempCol.blue) * inv255
  local valueTarget = InCol.red * inv255
  SatMax = 100 * math.min((1.0 - valueTarget) / (1.0 - valueHue), 1.0)
  Sat = math.min(Sat, SatMax)

  -- Calculating the final colour
  tempCol = hsv2rgb(Hue, Sat / 100, 1.0)
  local valueSat = rgb2v(tempCol.red, tempCol.green, tempCol.blue) * inv255
  local valueMultiplier = math.min(valueTarget / valueSat, 1.0)
  OutCol = Color(tempCol.red * valueMultiplier, tempCol.green * valueMultiplier, tempCol.blue * valueMultiplier, 255)
end



local function reloadColors(windowBounds)
  local dlg = Dialog{ title="Orange's Colourisation Tool"}
  dlg
  :shades
  {
    id = "mainColors",
    label = "Target",
    colors = {InCol},
    onclick = function(ev)
      if (ev.button == MouseButton.LEFT) then
        app.fgColor = ev.color
      end
      if (ev.button == MouseButton.RIGHT) then
        app.bgColor = ev.color
      end
    end,
    calculateCol();
  }
  :button
  {
    id = "buttonSetGrey",
    text = "Set",
    onclick = function(ev)
        local tempColor = Color{}
        tempColor = app.fgColor
        InCol = Color{}
        InCol.red = tempColor.red
        InCol.green = tempColor.red
        InCol.blue = tempColor.red
        InCol.alpha = tempColor.alpha
        dlg:close()
        reloadColors(dlg.bounds)
    end
  }
  :slider
  {
    id = "sliderHue",
    label = "Hue",
    min = 0,
    max = 360,
    value = Hue,
    onrelease = function(ev)
      Hue = dlg.data.sliderHue
      dlg:close()
      reloadColors(dlg.bounds)
    end
  }
  :slider
  {
    id = "sliderSat",
    label = "Saturation",
    min = 0,
    max = SatMax,
    value = Sat,
    onrelease = function(ev)
      Sat = dlg.data.sliderSat
      dlg:close()
      reloadColors(dlg.bounds)
    end
  }
  :shades
  {
    id = "colOut",
    label = "Result",
    colors = {OutCol},
    onclick = function(ev)
      if (ev.button == MouseButton.LEFT) then
        app.fgColor = ev.color
      end
      if (ev.button == MouseButton.RIGHT) then
        app.bgColor = ev.color
      end
    end
  }
  :show{wait = false, bounds = windowBounds}
end

reloadColors(windowBounds);